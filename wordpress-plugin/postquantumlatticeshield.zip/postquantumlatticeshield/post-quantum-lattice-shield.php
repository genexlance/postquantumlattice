<?php
/**
 * Plugin Name: Post Quantum Lattice Shield
 * Plugin URI: https://github.com/your-username/post-quantum-lattice-shield
 * Description: Secure form data encryption using post-quantum ML-KEM-512 cryptography. Integrates with Gravity Forms to encrypt sensitive field data.
 * Version: 1.0.0
 * Author: Your Name
 * License: MIT
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Text Domain: pqls
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PQLS_VERSION', '1.0.0');
define('PQLS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PQLS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PQLS_MICROSERVICE_URL', 'https://postquantumlatticeshield.netlify.app/api');

/**
 * Main plugin class
 */
class PostQuantumLatticeShield {
    
    private $option_name = 'pqls_settings';
    private $encrypted_fields = [];
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        
        // Gravity Forms hooks
        add_filter('gform_pre_submission_filter', array($this, 'pre_submission_encrypt'), 10, 1);
        
        // AJAX hooks
        add_action('wp_ajax_pqls_regenerate_keys', array($this, 'ajax_regenerate_keys'));
        add_action('wp_ajax_pqls_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_pqls_test_decrypt', array($this, 'ajax_test_decrypt'));
        add_action('wp_ajax_pqls_decrypt_field', array($this, 'ajax_decrypt_field'));
        add_action('wp_ajax_pqls_export_csv', array($this, 'ajax_export_csv'));
        
        // Enhanced visual indicators for encrypted fields
        add_filter('gform_entry_field_value', array($this, 'format_encrypted_entry_display'), 10, 4);
        add_filter('gform_entries_field_value', array($this, 'format_encrypted_entry_display'), 10, 4);
        add_action('gform_entry_info', array($this, 'add_encryption_notice'), 10, 2);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_gravity_forms_scripts'));
        add_action('gform_entries_first_column_actions', array($this, 'add_csv_export_buttons'), 10, 4);
        
        // Debug logging for hook registration
        error_log('PQLS: Hooks registered - gform_entry_field_value and gform_entries_field_value filters added');
        
        // Gravity Forms field editor integration
        add_action('gform_field_advanced_settings', array($this, 'add_encryption_field_setting'), 10, 2);
        add_filter('gform_tooltips', array($this, 'add_encryption_tooltips'));
        add_action('gform_editor_js', array($this, 'add_encryption_editor_js'));
        
        // Frontend field indicators and processing
        add_filter('gform_field_content', array($this, 'add_encryption_field_indicator'), 10, 5);
        add_filter('gform_field_css_class', array($this, 'add_encryption_field_class'), 10, 3);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        
        // Fix plugin download filename
        add_action('load-plugin-editor.php', array($this, 'intercept_plugin_download'));
        add_action('load-plugins.php', array($this, 'intercept_plugin_download'));
        add_action('template_redirect', array($this, 'check_plugin_download'));
        add_action('admin_init', array($this, 'handle_plugin_download_admin'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load plugin text domain
        load_plugin_textdomain('pqls', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        
        // Check if Gravity Forms is active
        if (!class_exists('GFForms')) {
            add_action('admin_notices', array($this, 'gravity_forms_missing_notice'));
            return;
        }
        
        // Load encrypted fields configuration
        $settings = get_option($this->option_name, array());
        $this->encrypted_fields = isset($settings['encrypted_fields']) ? $settings['encrypted_fields'] : array();
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Generate initial key pair
        $this->generate_keypair();
        
        // Set default settings
        $default_settings = array(
            'microservice_url' => PQLS_MICROSERVICE_URL,
            'encrypted_fields' => array(),
            'rate_limit' => 100,
            'timeout' => 30
        );
        
        add_option($this->option_name, $default_settings);
        
        // Add capabilities to admin
        $role = get_role('administrator');
        if ($role) {
            $role->add_cap('manage_pqls');
            $role->add_cap('decrypt_pqls_data');
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Remove capabilities
        $role = get_role('administrator');
        if ($role) {
            $role->remove_cap('manage_pqls');
            $role->remove_cap('decrypt_pqls_data');
        }
    }
    
    /**
     * Generate ML-KEM keypair
     */
    private function generate_keypair() {
        // For WordPress, we'll generate the keypair by calling our microservice
        $settings = get_option($this->option_name, array());
        $microservice_url = $settings['microservice_url'] ?? PQLS_MICROSERVICE_URL;
        
        $api_key = get_option('pqls_api_key');
        $headers = array(
            'Content-Type' => 'application/json',
        );
        
        if ($api_key) {
            $headers['Authorization'] = 'Bearer ' . $api_key;
        }
        
        $response = wp_remote_get($microservice_url . '/generate-keypair', array(
            'timeout' => 30,
            'headers' => $headers
        ));
        
        if (is_wp_error($response)) {
            error_log('PQLS: Failed to generate keypair - ' . $response->get_error_message());
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code !== 200) {
            error_log('PQLS: Generate keypair failed with status ' . $status_code . ': ' . $body);
            return false;
        }
        
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('PQLS: Invalid JSON response: ' . json_last_error_msg());
            return false;
        }
        
        if (isset($data['publicKey']) && isset($data['privateKey'])) {
            update_option('pqls_public_key', $data['publicKey']);
            update_option('pqls_private_key', $data['privateKey']);
            update_option('pqls_algorithm', $data['algorithm']);
            update_option('pqls_key_generated', current_time('mysql'));
            return true;
        }
        
        error_log('PQLS: Response missing required keys: ' . print_r($data, true));
        return false;
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            __('Post Quantum Lattice Shield Settings', 'pqls'),
            __('PQ Lattice Shield', 'pqls'),
            'manage_pqls',
            'pqls-settings',
            array($this, 'admin_page')
        );
    }
    
    /**
     * Admin settings initialization
     */
    public function admin_init() {
        register_setting('pqls_settings', $this->option_name);
        register_setting('pqls_settings', 'pqls_api_key');
        
        // Enqueue admin scripts
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_enqueue_scripts($hook) {
        if ($hook !== 'settings_page_pqls-settings') {
            return;
        }
        
        wp_enqueue_script('pqls-admin', PQLS_PLUGIN_URL . 'assets/admin.js', array('jquery'), PQLS_VERSION, true);
        wp_localize_script('pqls-admin', 'pqls_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('pqls_nonce'),
            'strings' => array(
                'decrypting' => __('Decrypting...', 'pqls'),
                'decrypt_failed' => __('Decryption failed', 'pqls'),
                'copied' => __('Copied to clipboard', 'pqls')
            )
        ));
        
        wp_enqueue_style('pqls-admin', PQLS_PLUGIN_URL . 'assets/admin.css', array(), PQLS_VERSION);
    }
    
    /**
     * Admin page HTML
     */
    public function admin_page() {
        $settings = get_option($this->option_name, array());
        $public_key = get_option('pqls_public_key');
        $algorithm = get_option('pqls_algorithm', 'ml-kem-512');
        $key_generated = get_option('pqls_key_generated');
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('pqls_settings');
                do_settings_sections('pqls_settings');
                ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Microservice URL', 'pqls'); ?></th>
                        <td>
                            <input type="url" name="<?php echo $this->option_name; ?>[microservice_url]" 
                                   value="<?php echo esc_attr($settings['microservice_url'] ?? PQLS_MICROSERVICE_URL); ?>" 
                                   class="regular-text" required />
                            <p class="description"><?php _e('URL of your Netlify microservice endpoint', 'pqls'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('API Key', 'pqls'); ?></th>
                        <td>
                            <input type="password" name="pqls_api_key" 
                                   value="<?php echo esc_attr(get_option('pqls_api_key')); ?>" 
                                   class="regular-text" />
                            <p class="description"><?php _e('API key for microservice authentication (required for decryption)', 'pqls'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Public Key', 'pqls'); ?></th>
                        <td>
                            <textarea readonly class="large-text" rows="10"><?php echo esc_textarea($public_key); ?></textarea>
                            <p class="description">
                                <?php _e('Algorithm:', 'pqls'); ?> <strong><?php echo esc_html($algorithm); ?></strong><br>
                                <?php if ($key_generated): ?>
                                    <?php _e('Generated:', 'pqls'); ?> <?php echo esc_html($key_generated); ?>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Key Management', 'pqls'); ?></th>
                        <td>
                            <button type="button" id="regenerate-keys" class="button button-secondary">
                                <?php _e('Regenerate Key Pair', 'pqls'); ?>
                            </button>
                            <button type="button" id="test-connection" class="button button-secondary">
                                <?php _e('Test Connection', 'pqls'); ?>
                            </button>
                            <button type="button" id="test-decrypt" class="button button-secondary">
                                <?php _e('Test Decrypt', 'pqls'); ?>
                            </button>
                            <div id="key-status" class="notice" style="display:none; margin-top: 10px;"></div>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Encrypted Fields', 'pqls'); ?></th>
                        <td>
                            <div id="encrypted-fields-container">
                                <?php $this->render_encrypted_fields_settings($settings); ?>
                            </div>
                            <p class="description">
                                <?php _e('Select which Gravity Forms fields should be encrypted before storage.', 'pqls'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <div class="pqls-debug-info" style="margin-top: 20px; padding: 15px; background: #f0f0f0; border: 1px solid #ccc;">
                <h4>Debug Information</h4>
                <p><strong>API Key Status:</strong> <?php echo get_option('pqls_api_key') ? 'Set (' . strlen(get_option('pqls_api_key')) . ' characters)' : 'Not set'; ?></p>
                <p><strong>Private Key Status:</strong> <?php echo get_option('pqls_private_key') ? 'Set (' . strlen(get_option('pqls_private_key')) . ' characters)' : 'Not set'; ?></p>
                <p><strong>Microservice URL:</strong> <?php echo esc_html($settings['microservice_url'] ?? PQLS_MICROSERVICE_URL); ?></p>
                <p><strong>Current User Can Decrypt:</strong> <?php echo current_user_can('decrypt_pqls_data') ? 'Yes' : 'No'; ?></p>
                <p><em>Check WordPress debug.log for detailed error messages</em></p>
            </div>
            
            <div class="pqls-info">
                <h3><?php _e('Security Information', 'pqls'); ?></h3>
                <ul>
                    <li><?php _e('Public keys are safe to store and can be viewed by administrators.', 'pqls'); ?></li>
                    <li><?php _e('Private keys are stored securely and used only for key generation.', 'pqls'); ?></li>
                    <li><?php _e('All encryption is performed by the remote microservice via HTTPS.', 'pqls'); ?></li>
                    <li><?php _e('ML-KEM-512 provides quantum-resistant security.', 'pqls'); ?></li>
                </ul>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Regenerate keys
            $('#regenerate-keys').on('click', function() {
                if (!confirm('<?php _e('Are you sure? This will invalidate all previously encrypted data!', 'pqls'); ?>')) {
                    return;
                }
                
                $.ajax({
                    url: pqls_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'pqls_regenerate_keys',
                        nonce: pqls_ajax.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert('<?php _e('Failed to regenerate keys', 'pqls'); ?>');
                        }
                    }
                });
            });
            
            // Test connection
            $('#test-connection').on('click', function() {
                $.ajax({
                    url: pqls_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'pqls_test_connection',
                        nonce: pqls_ajax.nonce
                    },
                    success: function(response) {
                        $('#key-status').removeClass('notice-error notice-success')
                            .addClass(response.success ? 'notice-success' : 'notice-error')
                            .html('<p>' + response.data + '</p>')
                            .show();
                    }
                });
            });
            
            // Test decrypt
            $('#test-decrypt').on('click', function() {
                var $button = $(this);
                $button.prop('disabled', true).text('Testing...');
                
                $.ajax({
                    url: pqls_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'pqls_test_decrypt',
                        nonce: pqls_ajax.nonce
                    },
                    success: function(response) {
                        $('#key-status').removeClass('notice-error notice-success')
                            .addClass(response.success ? 'notice-success' : 'notice-error')
                            .html('<p>' + response.data + '</p>')
                            .show();
                    },
                    complete: function() {
                        $button.prop('disabled', false).text('<?php _e('Test Decrypt', 'pqls'); ?>');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render encrypted fields settings
     */
    private function render_encrypted_fields_settings($settings) {
        $encrypted_fields = $settings['encrypted_fields'] ?? array();
        $forms = GFAPI::get_forms();
        
        if (empty($forms)) {
            echo '<p>' . __('No Gravity Forms found.', 'pqls') . '</p>';
            return;
        }
        
        foreach ($forms as $form) {
            echo '<h4>' . esc_html($form['title']) . ' (ID: ' . $form['id'] . ')</h4>';
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>Field</th><th>Type</th><th>Encrypt</th></tr></thead>';
            echo '<tbody>';
            
            foreach ($form['fields'] as $field) {
                $field_key = $form['id'] . '_' . $field->id;
                $is_encrypted = in_array($field_key, $encrypted_fields);
                
                echo '<tr>';
                echo '<td>' . esc_html($field->label) . '</td>';
                echo '<td>' . esc_html($field->type) . '</td>';
                echo '<td>';
                echo '<input type="checkbox" name="' . $this->option_name . '[encrypted_fields][]" ';
                echo 'value="' . esc_attr($field_key) . '" ';
                echo checked($is_encrypted, true, false) . ' />';
                echo '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
        }
    }
    
    /**
     * Encrypt form data before submission
     */
    public function pre_submission_encrypt($form) {
        $public_key = get_option('pqls_public_key');
        
        if (!$public_key) {
            error_log('PQLS: No public key available for encryption');
            return $form;
        }
        
        foreach ($form['fields'] as &$field) {
            // Check if this specific field has encryption enabled
            if (!empty($field->pqls_enable_encryption)) {
                $field_value = rgpost('input_' . $field->id);
                
                if (!empty($field_value)) {
                    $encrypted_value = $this->encrypt_data($field_value, $public_key);
                    
                    if ($encrypted_value) {
                        $_POST['input_' . $field->id] = $encrypted_value;
                    }
                }
            }
        }
        
        return $form;
    }
    
    /**
     * Encrypt data using microservice
     */
    private function encrypt_data($data, $public_key) {
        $settings = get_option($this->option_name, array());
        $microservice_url = $settings['microservice_url'] ?? PQLS_MICROSERVICE_URL;
        
        $payload = array(
            'publicKey' => $public_key,
            'payload' => $data
        );
        
        $api_key = get_option('pqls_api_key');
        $headers = array(
            'Content-Type' => 'application/json',
        );
        
        if ($api_key) {
            $headers['Authorization'] = 'Bearer ' . $api_key;
        }
        
        $response = wp_remote_post($microservice_url . '/encrypt', array(
            'timeout' => 30,
            'headers' => $headers,
            'body' => json_encode($payload)
        ));
        
        if (is_wp_error($response)) {
            error_log('PQLS: Encryption failed - ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        if (isset($result['encrypted'])) {
            return '[ENCRYPTED:' . $result['encrypted'] . ']';
        }
        
        return false;
    }
    
    /**
     * Decrypt data using microservice
     */
    private function decrypt_data($encrypted_data) {
        // Extract the encrypted data from the wrapper
        if (!preg_match('/^\[ENCRYPTED:(.+)\]$/', $encrypted_data, $matches)) {
            return false; // Not encrypted data
        }
        
        $ciphertext = $matches[1];
        $private_key = get_option('pqls_private_key');
        
        if (!$private_key) {
            error_log('PQLS: No private key available for decryption');
            return false;
        }
        
        $settings = get_option($this->option_name, array());
        $microservice_url = $settings['microservice_url'] ?? PQLS_MICROSERVICE_URL;
        
        $payload = array(
            'privateKey' => $private_key,
            'ciphertext' => $ciphertext
        );
        
        $api_key = get_option('pqls_api_key');
        $headers = array(
            'Content-Type' => 'application/json',
        );
        
        if ($api_key) {
            $headers['Authorization'] = 'Bearer ' . $api_key;
            error_log('PQLS: Using API key for decryption (length: ' . strlen($api_key) . ')');
        } else {
            error_log('PQLS: No API key configured for decryption');
        }
        
        error_log('PQLS: Attempting decrypt with URL: ' . $microservice_url . '/decrypt');
        error_log('PQLS: Request headers: ' . print_r($headers, true));
        error_log('PQLS: Request payload keys: ' . implode(', ', array_keys($payload)));
        
        $response = wp_remote_post($microservice_url . '/decrypt', array(
            'timeout' => 30,
            'headers' => $headers,
            'body' => json_encode($payload)
        ));
        
        if (is_wp_error($response)) {
            error_log('PQLS: Decryption failed - ' . $response->get_error_message());
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code !== 200) {
            error_log('PQLS: Decryption failed with status ' . $status_code . ': ' . $body);
            // Log response headers for debugging
            $response_headers = wp_remote_retrieve_headers($response);
            error_log('PQLS: Response headers: ' . print_r($response_headers, true));
            return false;
        }
        
        $result = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('PQLS: Invalid JSON response in decryption: ' . json_last_error_msg());
            return false;
        }
        
        if (isset($result['decrypted'])) {
            error_log('PQLS: Decryption successful');
            return $result['decrypted'];
        }
        
        error_log('PQLS: Decryption response missing decrypted field: ' . print_r($result, true));
        return false;
    }
    
    /**
     * AJAX: Decrypt field value
     */
    public function ajax_decrypt_field() {
        check_ajax_referer('pqls_nonce', 'nonce');
        
        if (!current_user_can('decrypt_pqls_data')) {
            wp_die(__('Insufficient permissions', 'pqls'));
        }
        
        $encrypted_data = sanitize_text_field($_POST['encrypted_data']);
        
        if (empty($encrypted_data)) {
            wp_send_json(array(
                'success' => false,
                'data' => __('No encrypted data provided', 'pqls')
            ));
        }
        
        // Debug logging
        error_log('PQLS: Attempting to decrypt data: ' . substr($encrypted_data, 0, 50) . '...');
        
        $decrypted = $this->decrypt_data($encrypted_data);
        
        if ($decrypted !== false) {
            // Log the decryption attempt for audit purposes
            error_log('PQLS: Field decrypted successfully by user ' . get_current_user_id() . ' at ' . current_time('mysql'));
            
            wp_send_json(array(
                'success' => true,
                'data' => $decrypted
            ));
        } else {
            error_log('PQLS: Decryption failed for user ' . get_current_user_id() . ' - check previous error logs');
            wp_send_json(array(
                'success' => false,
                'data' => __('Decryption failed - check error logs for details', 'pqls')
            ));
        }
    }
    
    /**
     * AJAX: Export CSV with decrypt/redaction options
     */
    public function ajax_export_csv() {
        check_ajax_referer('pqls_nonce', 'nonce');
        
        if (!current_user_can('manage_pqls')) {
            wp_die(__('Insufficient permissions', 'pqls'));
        }
        
        $form_id = intval($_POST['form_id']);
        $export_type = sanitize_text_field($_POST['export_type']); // 'decrypt' or 'redact'
        
        if (!$form_id) {
            wp_send_json(array(
                'success' => false,
                'data' => __('Invalid form ID', 'pqls')
            ));
        }
        
        // Get form and entries
        $form = GFAPI::get_form($form_id);
        if (!$form) {
            wp_send_json(array(
                'success' => false,
                'data' => __('Form not found', 'pqls')
            ));
        }
        
        $entries = GFAPI::get_entries($form_id);
        if (!$entries) {
            wp_send_json(array(
                'success' => false,
                'data' => __('No entries found', 'pqls')
            ));
        }
        
        // Generate CSV
        $csv_data = $this->generate_csv_data($form, $entries, $export_type);
        
        if ($csv_data) {
            $filename = 'form_' . $form_id . '_' . $export_type . '_' . date('Y-m-d_H-i-s') . '.csv';
            
            // Log export for audit
            error_log('PQLS: CSV export (' . $export_type . ') for form ' . $form_id . ' by user ' . get_current_user_id() . ' at ' . current_time('mysql'));
            
            wp_send_json(array(
                'success' => true,
                'data' => array(
                    'filename' => $filename,
                    'csv_data' => $csv_data
                )
            ));
        } else {
            wp_send_json(array(
                'success' => false,
                'data' => __('Failed to generate CSV', 'pqls')
            ));
        }
    }
    
    /**
     * Generate CSV data with decrypt/redaction options
     */
    private function generate_csv_data($form, $entries, $export_type) {
        $csv_lines = array();
        
        // Build header row
        $headers = array('Entry ID', 'Date Created', 'IP Address', 'Source URL');
        foreach ($form['fields'] as $field) {
            $headers[] = $field->label;
        }
        $csv_lines[] = $headers;
        
        // Process entries
        foreach ($entries as $entry) {
            $row = array(
                $entry['id'],
                $entry['date_created'],
                $entry['ip'],
                $entry['source_url']
            );
            
            foreach ($form['fields'] as $field) {
                $field_value = rgar($entry, $field->id);
                
                // Check if field is encrypted
                if ($field_value !== null && strpos($field_value, '[ENCRYPTED:') === 0) {
                    if ($export_type === 'decrypt' && current_user_can('decrypt_pqls_data')) {
                        // Decrypt the field
                        $decrypted = $this->decrypt_data($field_value);
                        $row[] = $decrypted !== false ? $decrypted : '[DECRYPT_FAILED]';
                    } else {
                        // Redact or show as encrypted
                        $row[] = '[ENCRYPTED_DATA_REDACTED]';
                    }
                } else {
                    $row[] = $field_value;
                }
            }
            
            $csv_lines[] = $row;
        }
        
        // Convert to CSV format
        $csv_content = '';
        foreach ($csv_lines as $line) {
            $csv_content .= '"' . implode('","', array_map('str_replace', array_fill(0, count($line), '"'), array_fill(0, count($line), '""'), $line)) . '"' . "\n";
        }
        
        return $csv_content;
    }
    
    /**
     * AJAX: Regenerate keys
     */
    public function ajax_regenerate_keys() {
        check_ajax_referer('pqls_nonce', 'nonce');
        
        if (!current_user_can('manage_pqls')) {
            wp_die(__('Insufficient permissions', 'pqls'));
        }
        
        $success = $this->generate_keypair();
        
        wp_send_json(array(
            'success' => $success,
            'data' => $success ? __('Keys regenerated successfully', 'pqls') : __('Failed to regenerate keys', 'pqls')
        ));
    }
    
    /**
     * AJAX: Test connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('pqls_nonce', 'nonce');
        
        if (!current_user_can('manage_pqls')) {
            wp_die(__('Insufficient permissions', 'pqls'));
        }
        
        $settings = get_option($this->option_name, array());
        $microservice_url = $settings['microservice_url'] ?? PQLS_MICROSERVICE_URL;
        
        $api_key = get_option('pqls_api_key');
        $headers = array();
        
        if ($api_key) {
            $headers['Authorization'] = 'Bearer ' . $api_key;
        }
        
        $response = wp_remote_get($microservice_url . '/generate-keypair', array(
            'timeout' => 10,
            'headers' => $headers
        ));
        
        if (is_wp_error($response)) {
            wp_send_json(array(
                'success' => false,
                'data' => __('Connection failed: ', 'pqls') . $response->get_error_message()
            ));
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        wp_send_json(array(
            'success' => $code === 200,
            'data' => $code === 200 ? __('Connection successful!', 'pqls') : __('Connection failed. Status: ', 'pqls') . $code
        ));
    }
    
    /**
     * AJAX: Test decrypt functionality
     */
    public function ajax_test_decrypt() {
        check_ajax_referer('pqls_nonce', 'nonce');
        
        if (!current_user_can('manage_pqls')) {
            wp_die(__('Insufficient permissions', 'pqls'));
        }
        
        // Create a test encrypted value
        $test_plain = 'Test decryption: ' . current_time('mysql');
        
        // First encrypt the test data
        $public_key = get_option('pqls_public_key');
        if (!$public_key) {
            wp_send_json(array(
                'success' => false,
                'data' => __('No public key available - generate keys first', 'pqls')
            ));
        }
        
        $encrypted = $this->encrypt_data($test_plain, $public_key);
        if (!$encrypted) {
            wp_send_json(array(
                'success' => false,
                'data' => __('Encryption test failed', 'pqls')
            ));
        }
        
        // Now test decryption
        $decrypted = $this->decrypt_data($encrypted);
        
        if ($decrypted !== false) {
            $success = ($decrypted === $test_plain);
            wp_send_json(array(
                'success' => $success,
                'data' => $success ? 
                    __('Encrypt/decrypt test successful!', 'pqls') : 
                    __('Decryption returned wrong data: ', 'pqls') . $decrypted
            ));
        } else {
            wp_send_json(array(
                'success' => false,
                'data' => __('Decryption test failed - check error logs', 'pqls')
            ));
        }
    }
    
    /**
     * Show notice if Gravity Forms is missing
     */
    public function gravity_forms_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Post Quantum Lattice Shield requires Gravity Forms to be installed and activated.', 'pqls'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Format encrypted field display in Gravity Forms entries
     */
    public function format_encrypted_entry_display($value, $field, $entry, $form) {
        // Debug logging
        error_log('PQLS: format_encrypted_entry_display called with value: ' . substr($value, 0, 50) . '...');
        error_log('PQLS: Value is null: ' . ($value === null ? 'yes' : 'no'));
        error_log('PQLS: Value contains [ENCRYPTED:: ' . (strpos($value, '[ENCRYPTED:') !== false ? 'yes' : 'no'));
        
        // Check if this value is encrypted
        if ($value !== null && strpos($value, '[ENCRYPTED:') === 0) {
            error_log('PQLS: Processing encrypted field display');
            
            $encrypted_data = substr($value, 11, -1); // Remove [ENCRYPTED: and ]
            $short_preview = substr($encrypted_data, 0, 20) . '...';
            
            // Handle both field object and field ID
            $field_id = is_object($field) ? $field->id : $field;
            
            // Check if user can decrypt
            $can_decrypt = current_user_can('decrypt_pqls_data');
            $decrypt_button = '';
            
            if ($can_decrypt) {
                $decrypt_button = '<button type="button" class="pqls-decrypt-btn button-secondary" 
                                          data-encrypted="' . esc_attr($value) . '" 
                                          data-field-id="' . esc_attr($field_id) . '"
                                          title="' . esc_attr__('Decrypt this field value', 'pqls') . '">
                                     <span class="dashicons dashicons-visibility"></span> ' . __('Decrypt', 'pqls') . '
                                   </button>';
            }
            
            $formatted_output = sprintf(
                '<div class="pqls-encrypted-field">
                    <div class="pqls-encrypted-badge">💫🔒💫</div>
                    <div class="pqls-encrypted-content">
                        <div class="pqls-encrypted-preview">%s</div>
                        <div class="pqls-decrypted-content" style="display: none;">
                            <div class="pqls-decrypted-value"></div>
                            <div class="pqls-security-warning">
                                <small><strong>%s</strong> %s</small>
                            </div>
                            <button type="button" class="pqls-hide-btn button-secondary">
                                <span class="dashicons dashicons-hidden"></span> %s
                            </button>
                        </div>
                        <div class="pqls-encrypted-full" style="display: none;">%s</div>
                        <div class="pqls-field-actions">
                            %s
                            <button type="button" class="pqls-toggle-encrypted button-secondary" 
                                    data-target-preview=".pqls-encrypted-preview" 
                                    data-target-full=".pqls-encrypted-full">
                                <span class="show-text">Show Full</span>
                                <span class="hide-text" style="display: none;">Hide</span>
                            </button>
                        </div>
                    </div>
                </div>',
                esc_html($short_preview),
                __('⚠️ Security Warning:', 'pqls'),
                __('Decrypted data is now visible and vulnerable. Hide it when finished.', 'pqls'),
                __('Hide', 'pqls'),
                '<textarea readonly class="pqls-encrypted-textarea">' . esc_textarea($encrypted_data) . '</textarea>',
                $decrypt_button
            );
            
            error_log('PQLS: Returning formatted output (length: ' . strlen($formatted_output) . ')');
            return $formatted_output;
        }
        
        error_log('PQLS: Value not encrypted, returning as-is');
        return $value;
    }
    
    /**
     * Add encryption notice to entry info
     */
    public function add_encryption_notice($form, $entry) {
        $has_encrypted = false;
        
        foreach ($entry as $key => $value) {
            if ($value !== null && strpos($value, '[ENCRYPTED:') === 0) {
                $has_encrypted = true;
                break;
            }
        }
        
        if ($has_encrypted) {
            echo '<div class="pqls-entry-notice">
                    <div class="notice notice-info inline">
                        <p><strong>🔒 Post-Quantum Encryption:</strong> This entry contains encrypted fields protected with ML-KEM-512 lattice-based cryptography.</p>
                    </div>
                  </div>';
        }
    }
    
    /**
     * Add CSV export buttons to entries page
     */
    public function add_csv_export_buttons($form_id, $field_id, $value, $entry) {
        // Only show on the entries list page, not individual entry pages
        if (!rgget('page') || rgget('page') !== 'gf_entries') {
            return;
        }
        
        static $buttons_added = false;
        if ($buttons_added) {
            return;
        }
        
        $buttons_added = true;
        
        // Check if form has encrypted fields
        $form = GFAPI::get_form($form_id);
        $has_encrypted_fields = false;
        
        if ($form) {
            foreach ($form['fields'] as $field) {
                if (!empty($field->pqls_enable_encryption)) {
                    $has_encrypted_fields = true;
                    break;
                }
            }
        }
        
        if ($has_encrypted_fields && current_user_can('manage_pqls')) {
            echo '<div class="pqls-csv-export-buttons" style="margin: 10px 0;">';
            echo '<h4>' . __('Post-Quantum Lattice Shield Exports', 'pqls') . '</h4>';
            
            if (current_user_can('decrypt_pqls_data')) {
                echo '<button type="button" class="button button-primary pqls-export-csv" data-form-id="' . esc_attr($form_id) . '" data-export-type="decrypt">';
                echo '<span class="dashicons dashicons-download"></span> ' . __('Export CSV (Decrypted)', 'pqls');
                echo '</button> ';
            }
            
            echo '<button type="button" class="button button-secondary pqls-export-csv" data-form-id="' . esc_attr($form_id) . '" data-export-type="redact">';
            echo '<span class="dashicons dashicons-download"></span> ' . __('Export CSV (Redacted)', 'pqls');
            echo '</button>';
            
            echo '<div class="pqls-export-status" style="margin-top: 10px; display: none;"></div>';
            echo '</div>';
            
            // Add JavaScript for CSV export
            ?>
            <script>
            jQuery(document).ready(function($) {
                $('.pqls-export-csv').on('click', function() {
                    var $button = $(this);
                    var formId = $button.data('form-id');
                    var exportType = $button.data('export-type');
                    var $status = $('.pqls-export-status');
                    
                    $button.prop('disabled', true);
                    $status.removeClass('notice-error notice-success').addClass('notice-info').show();
                    $status.html('<p>Generating CSV export...</p>');
                    
                    $.ajax({
                        url: pqls_ajax.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'pqls_export_csv',
                            nonce: pqls_ajax.nonce,
                            form_id: formId,
                            export_type: exportType
                        },
                        success: function(response) {
                            if (response.success) {
                                // Create download link
                                var blob = new Blob([response.data.csv_data], { type: 'text/csv' });
                                var link = document.createElement('a');
                                link.href = window.URL.createObjectURL(blob);
                                link.download = response.data.filename;
                                link.click();
                                
                                $status.removeClass('notice-info').addClass('notice-success');
                                $status.html('<p>CSV exported successfully!</p>');
                                
                                setTimeout(function() {
                                    $status.fadeOut();
                                }, 3000);
                            } else {
                                $status.removeClass('notice-info').addClass('notice-error');
                                $status.html('<p>Export failed: ' + response.data + '</p>');
                            }
                        },
                        error: function() {
                            $status.removeClass('notice-info').addClass('notice-error');
                            $status.html('<p>Export failed due to server error</p>');
                        },
                        complete: function() {
                            $button.prop('disabled', false);
                        }
                    });
                });
            });
            </script>
            <?php
        }
    }
    
    /**
     * Enqueue scripts for Gravity Forms pages
     */
    public function enqueue_gravity_forms_scripts($hook) {
        // Debug logging
        error_log('PQLS: enqueue_gravity_forms_scripts called with hook: ' . $hook);
        
        // Only load on Gravity Forms pages
        if (strpos($hook, 'gf_') === false && strpos($hook, 'gravityforms') === false) {
            error_log('PQLS: Not a Gravity Forms page, skipping script enqueue');
            return;
        }
        
        error_log('PQLS: Enqueuing Gravity Forms scripts and styles');
        
        wp_enqueue_style('pqls-gravity-forms', PQLS_PLUGIN_URL . 'assets/gravity-forms.css', array(), PQLS_VERSION);
        wp_enqueue_script('pqls-gravity-forms-base', PQLS_PLUGIN_URL . 'assets/admin.js', array('jquery'), PQLS_VERSION, true);
        
        // Localize script for AJAX calls
        wp_localize_script('pqls-gravity-forms-base', 'pqls_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('pqls_nonce'),
            'strings' => array(
                'decrypting' => __('Decrypting...', 'pqls'),
                'decrypt_failed' => __('Decryption failed', 'pqls'),
                'copied' => __('Copied to clipboard', 'pqls')
            )
        ));
        
        error_log('PQLS: Adding inline script for decrypt functionality');
        
        // Add decrypt functionality inline
        wp_add_inline_script('pqls-gravity-forms-base', "
            jQuery(document).ready(function($) {
                // Decrypt button click handler
                $(document).on('click', '.pqls-decrypt-btn', function() {
                    var \$button = $(this);
                    var \$field = \$button.closest('.pqls-encrypted-field');
                    var \$preview = \$field.find('.pqls-encrypted-preview');
                    var \$decrypted = \$field.find('.pqls-decrypted-content');
                    var \$decryptedValue = \$field.find('.pqls-decrypted-value');
                    var encryptedData = \$button.data('encrypted');
                    
                    // Show loading state
                    \$button.html('<span class=\"dashicons dashicons-update spin\"></span> Decrypting...');
                    \$button.prop('disabled', true);
                    
                    $.ajax({
                        url: pqls_ajax.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'pqls_decrypt_field',
                            nonce: pqls_ajax.nonce,
                            encrypted_data: encryptedData
                        },
                        success: function(response) {
                            if (response.success) {
                                \$decryptedValue.html('<pre>' + response.data + '</pre>');
                                \$preview.fadeOut(200, function() {
                                    \$decrypted.fadeIn(200);
                                });
                                \$button.hide();
                            } else {
                                alert(response.data || 'Decryption failed');
                                \$button.html('<span class=\"dashicons dashicons-visibility\"></span> Decrypt');
                            }
                        },
                        error: function() {
                            alert('Decryption failed');
                            \$button.html('<span class=\"dashicons dashicons-visibility\"></span> Decrypt');
                        },
                        complete: function() {
                            \$button.prop('disabled', false);
                        }
                    });
                });
                
                // Hide decrypted button click handler
                $(document).on('click', '.pqls-hide-btn', function() {
                    var \$button = $(this);
                    var \$field = \$button.closest('.pqls-encrypted-field');
                    var \$preview = \$field.find('.pqls-encrypted-preview');
                    var \$decrypted = \$field.find('.pqls-decrypted-content');
                    var \$decryptBtn = \$field.find('.pqls-decrypt-btn');
                    
                    \$decrypted.fadeOut(200, function() {
                        \$preview.fadeIn(200);
                        \$decryptBtn.show();
                    });
                });
            });
        ");
    }
    
    /**
     * Add encryption field setting to Gravity Forms field editor
     */
    public function add_encryption_field_setting($position, $form_id) {
        if ($position == 25) { // Add after Advanced Settings
            ?>
            <li class="pqls_enable_encryption_setting field_setting">
                <div class="pqls-encryption-setting">
                    <label for="pqls_enable_encryption" class="section_label">
                        <?php esc_html_e('Post-Quantum Encryption', 'pqls'); ?>
                        <?php gform_tooltip('pqls_enable_encryption'); ?>
                    </label>
                    <input type="checkbox" id="pqls_enable_encryption" onclick="SetFieldProperty('pqls_enable_encryption', this.checked);" />
                    <label for="pqls_enable_encryption" class="inline">
                        <?php esc_html_e('Enable encryption for this field', 'pqls'); ?>
                    </label>
                    <div class="pqls-encryption-info">
                        <small>
                            <span class="dashicons dashicons-shield"></span>
                            <?php esc_html_e('This field will be encrypted with ML-KEM-512 before saving to database', 'pqls'); ?>
                        </small>
                    </div>
                </div>
            </li>
            <?php
        }
    }
    
    /**
     * Add encryption tooltips to Gravity Forms
     */
    public function add_encryption_tooltips($tooltips) {
        $tooltips['pqls_enable_encryption'] = sprintf(
            '<h6>%s</h6><p>%s</p><p>%s</p>',
            __('Post-Quantum Encryption', 'pqls'),
            __('When enabled, this field\'s data will be encrypted using ML-KEM-512 lattice-based cryptography before being saved to the database.', 'pqls'),
            __('This provides protection against quantum computer attacks and ensures long-term data security.', 'pqls')
        );
        return $tooltips;
    }
    
    /**
     * Add JavaScript for encryption field editor
     */
    public function add_encryption_editor_js() {
        ?>
        <script type="text/javascript">
            // Add encryption setting to supported field types
            fieldSettings.text += ", .pqls_enable_encryption_setting";
            fieldSettings.textarea += ", .pqls_enable_encryption_setting";
            fieldSettings.email += ", .pqls_enable_encryption_setting";
            fieldSettings.phone += ", .pqls_enable_encryption_setting";
            fieldSettings.name += ", .pqls_enable_encryption_setting";
            fieldSettings.address += ", .pqls_enable_encryption_setting";
            fieldSettings.website += ", .pqls_enable_encryption_setting";
            fieldSettings.number += ", .pqls_enable_encryption_setting";
            fieldSettings.date += ", .pqls_enable_encryption_setting";
            fieldSettings.time += ", .pqls_enable_encryption_setting";
            fieldSettings.select += ", .pqls_enable_encryption_setting";
            fieldSettings.multiselect += ", .pqls_enable_encryption_setting";
            fieldSettings.radio += ", .pqls_enable_encryption_setting";
            fieldSettings.checkbox += ", .pqls_enable_encryption_setting";
            
            // Bind to the load field settings event
            jQuery(document).bind('gform_load_field_settings', function(event, field, form) {
                // Set the encryption checkbox based on field property
                var isEncrypted = field.pqls_enable_encryption == true;
                jQuery('#pqls_enable_encryption').prop('checked', isEncrypted);
                
                // Update visual indicator
                if (isEncrypted) {
                    jQuery('.field_selected').addClass('pqls-encrypted-field-editor');
                } else {
                    jQuery('.field_selected').removeClass('pqls-encrypted-field-editor');
                }
            });
            
            // Handle checkbox change event to save field property
            jQuery(document).on('change', '#pqls_enable_encryption', function() {
                var isChecked = jQuery(this).is(':checked');
                SetFieldProperty('pqls_enable_encryption', isChecked);
                
                // Update visual indicator immediately
                if (isChecked) {
                    jQuery('.field_selected').addClass('pqls-encrypted-field-editor');
                } else {
                    jQuery('.field_selected').removeClass('pqls-encrypted-field-editor');
                }
            });
            
            // Add visual styling to field editor
            jQuery('<style>')
                .prop('type', 'text/css')
                .html('.pqls-encryption-setting { padding: 10px; background: #f8f9fa; border: 1px solid #e2e8f0; border-radius: 4px; margin-top: 10px; } .pqls-encryption-setting .section_label { font-weight: 600; color: #2c3e50; display: flex; align-items: center; gap: 5px; } .pqls-encryption-info { margin-top: 8px; padding: 8px; background: #e8f5e8; border-radius: 3px; border-left: 3px solid #27ae60; } .pqls-encryption-info small { color: #27ae60; font-weight: 500; display: flex; align-items: center; gap: 5px; } .pqls-encrypted-field-editor { border: 2px solid #667eea !important; box-shadow: 0 0 0 1px #667eea !important; } .pqls-encrypted-field-editor::before { content: "💫🔒💫"; position: absolute; top: -10px; right: -10px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 2px 6px; border-radius: 10px; font-size: 10px; z-index: 1000; }')
                .appendTo('head');
        </script>
        <?php
    }
    
    /**
     * Add encryption indicator to form fields on frontend
     */
    public function add_encryption_field_indicator($content, $field, $value, $lead_id, $form_id) {
        // Check if field has encryption enabled
        if (!empty($field->pqls_enable_encryption)) {
            // Add encryption indicator to field
            $indicator = '<div class="pqls-field-encryption-indicator">
                            <span class="pqls-field-encryption-badge">💫🔒💫</span>
                            <span class="pqls-field-encryption-text">Encrypted Field</span>
                          </div>';
            
            // Insert indicator before the field input
            $content = preg_replace('/(<div[^>]*class="[^"]*ginput_container[^"]*"[^>]*>)/', '$1' . $indicator, $content);
        }
        
        return $content;
    }
    
    /**
     * Add CSS class to encrypted fields
     */
    public function add_encryption_field_class($classes, $field, $form) {
        if (!empty($field->pqls_enable_encryption)) {
            $classes .= ' pqls-encrypted-field-frontend';
        }
        return $classes;
    }
    
    /**
     * Enqueue frontend scripts for encrypted fields
     */
    public function enqueue_frontend_scripts() {
        // Only enqueue on pages with Gravity Forms
        if (!class_exists('GFCommon')) {
            return;
        }
        
        // Check if we're on a page that might have forms
        global $post;
        if (is_object($post) && (has_shortcode($post->post_content, 'gravityform') || 
            has_shortcode($post->post_content, 'gravityforms'))) {
            wp_enqueue_style('pqls-frontend', PQLS_PLUGIN_URL . 'assets/frontend.css', array(), PQLS_VERSION);
            wp_enqueue_script('pqls-frontend', PQLS_PLUGIN_URL . 'assets/frontend.js', array('jquery'), PQLS_VERSION, true);
        } else {
            // Always enqueue for safety - they're small files
            wp_enqueue_style('pqls-frontend', PQLS_PLUGIN_URL . 'assets/frontend.css', array(), PQLS_VERSION);
            wp_enqueue_script('pqls-frontend', PQLS_PLUGIN_URL . 'assets/frontend.js', array('jquery'), PQLS_VERSION, true);
        }
    }
    
    /**
     * Intercept plugin download to set proper filename
     */
    public function intercept_plugin_download() {
        if (isset($_GET['action']) && $_GET['action'] === 'download-plugin') {
            $plugin_file = isset($_GET['plugin']) ? sanitize_text_field($_GET['plugin']) : '';
            
            // Check if this is our plugin
            if (strpos($plugin_file, 'post-quantum-lattice-shield') !== false) {
                add_filter('wp_headers', array($this, 'set_download_headers'));
            }
        }
    }

    /**
     * Check if the current request is for a plugin download and set headers.
     */
    public function check_plugin_download() {
        if (isset($_GET['action']) && $_GET['action'] === 'download-plugin') {
            $plugin_file = isset($_GET['plugin']) ? sanitize_text_field($_GET['plugin']) : '';

            if (strpos($plugin_file, 'post-quantum-lattice-shield') !== false) {
                $this->set_download_headers(array()); // Headers are set via filter
            }
        }
    }
    
    /**
     * Set proper download headers for our plugin
     */
    public function set_download_headers($headers) {
        $headers['Content-Disposition'] = 'attachment; filename="postquantumlatticeshield.zip"';
        return $headers;
    }

    /**
     * Handle plugin download action in admin
     */
    public function handle_plugin_download_admin() {
        // Debug: Log all GET parameters on plugin pages
        if (isset($_GET['page']) && strpos($_GET['page'], 'plugin') !== false) {
            error_log('PQLS: Plugin page accessed with GET params: ' . print_r($_GET, true));
        }
        
        if (isset($_GET['action'])) {
            error_log('PQLS: Action detected: ' . $_GET['action']);
            
            // Check various download actions
            if (in_array($_GET['action'], ['download-plugin', 'download', 'edit-plugin-file'])) {
                $plugin_file = isset($_GET['plugin']) ? sanitize_text_field($_GET['plugin']) : '';
                $file = isset($_GET['file']) ? sanitize_text_field($_GET['file']) : '';
                
                error_log('PQLS: Download action detected. Plugin: ' . $plugin_file . ', File: ' . $file);
                
                if (strpos($plugin_file, 'post-quantum-lattice-shield') !== false || 
                    strpos($file, 'post-quantum-lattice-shield') !== false) {
                    error_log('PQLS: Our plugin download detected, setting headers');
                    add_filter('wp_headers', array($this, 'set_download_headers'));
                }
            }
        }
    }
}

// Initialize the plugin
new PostQuantumLatticeShield(); 